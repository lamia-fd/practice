package com.example.json

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val responseText=findViewById<TextView>(R.id.tv)
        val responseText2=findViewById<TextView>(R.id.textView)



        val apiInterface = APIClient().getClient()?.create(APIInterface::class.java)

        val call: Call<BookDetails?>? = apiInterface!!.doGetListResources()

        call?.enqueue(object : Callback<BookDetails?> {
            override fun onResponse(
                call: Call<BookDetails?>?,
                response: Response<BookDetails?>
            ) {
                Log.d("TAG", response.code().toString() + "")
                var displayResponse = ""
                var displayResponse2 = ""
                val resource: BookDetails? = response.body()
                val datumList = resource?.data
               // val datumList2 = resource?.total

                for (datum in datumList!!) {
                    displayResponse += """${datum.id.toString()} ${datum.name} ${datum.pantoneValue} ${datum.year}
"""


                }
                responseText.text = displayResponse
                displayResponse2 = """${resource?.total.toString()}"""




                responseText2.text = displayResponse2

            }

            override fun onFailure(call: Call<BookDetails?>, t: Throwable?) {
                call.cancel()
            }
        })

    }
}